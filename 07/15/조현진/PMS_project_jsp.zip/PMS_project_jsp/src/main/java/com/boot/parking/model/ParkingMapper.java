package com.boot.parking.model;

import java.util.List;
import java.util.Map;
import java.util.Date;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ParkingMapper {
	
	ManagerDTO login(ManagerDTO dto); // 관리자 로그인

	List<ParkingDTO> pList();
	
	List<UsersDTO> userList(Page pdto);
	
	List<UsersDTO> userSearchList(Page pdto);
	
	int ucount();
	
	int userSearchCount(Map<String, String> map);
	
	CarsDTO car(String car_num);
	
	int A_section_count();
	
	int B_section_count();
	
	String search_car(String car_num);
	
	int in_car(String car_num);
	
	int parking(ParkingDTO pdto);
	
	int out_time_update(String car_num);
	
	int out(String car_num);
	
	CarsDTO car_info(String car_num);
	
	UsersDTO user_info(String car_num);
	
	int record_in(ParkingRecordDTO rdto);
	
	int record_out(ParkingRecordDTO record);
	
	// 입차 시간 조회
	Date selectInTimeByCarNum(String car_num);

	// 출차 시 주차기록의 PK를 조회하는 메서드
	int selectRecordNumByCarNumAndInTime(@Param("car_num") String car_num, @Param("in_time") Date in_time);
	
	// 주차 기록
	List<ParkingRecordDTO> car_list(Page pdto);

	List<ParkingRecordDTO> parkingRecords();
	
	int count();
	
	int registration_user(UsersDTO udto);
	
	int scount(Map<String, String> map);

	List<ParkingRecordDTO> carlist_search(Page pdto);
	
	Integer searchamountfee(Map<String, String> map);
	
	// 요금 정보 조회
	ParkingFeeDTO getFee();

	// 요금 정보 수정
	int updateFee(ParkingFeeDTO fee);
	
	int userModify(UsersDTO udto);
	
	int userDelete(String user_car_num);
	
	int amountfee();
}
