package com.boot.parking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.boot.parking.model.*;

@Controller
public class ManagementController {

    @Autowired
    private ParkingMapper mapper;
    
    // 페이지 변수
    private final int rowsize = 10;
    private final int userRowsize = 5;
 	private int totalRecord = 0;

    // 관리자 로그인 화면
    @GetMapping("manager_login.go")
    public String loginForm() {
        return "parking_management/manager_login";
    }

    // 관리자 로그인 처리
    @PostMapping("manager_login_ok")
    public void loginOk(@RequestParam("manager_id") String id,
                        @RequestParam("manager_pwd") String pwd,
                        HttpSession session,
                        HttpServletResponse response) throws IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        ManagerDTO dto = new ManagerDTO();
        dto.setManager_id(id);
        dto.setManager_pwd(pwd);

        ManagerDTO result = mapper.login(dto);

        if (result != null) {
            session.setAttribute("manager_id", id);
            out.println("<script>");
            out.println("location.href='manager_main.go';");
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('아이디 또는 비밀번호가 틀립니다.');");
            out.println("history.back();");
            out.println("</script>");
        }
    }

    // 로그아웃 처리
    @GetMapping("logout.go")
    public void logout(HttpSession session, HttpServletResponse response) throws IOException {
        session.invalidate();

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<script>");
        out.println("alert('로그아웃 되었습니다.');");
        out.println("location.href='/'");
        out.println("</script>");
    }

    // 세션 체크 메서드 (중복 코드 방지용)
    private boolean isLoggedIn(HttpSession session) {
        return session != null && session.getAttribute("manager_id") != null;
    }

    // 로그인 체크 + alert + 리다이렉트 처리 메서드
    private void sendLoginAlertAndRedirect(HttpSession session, HttpServletResponse response) throws IOException {
    	
    	response.setContentType("text/html; charset=UTF-8");
    	// 캐시 방지 헤더 추가
    	response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    	response.setHeader("Pragma", "no-cache");
    	response.setDateHeader("Expires", 0);
    	
        PrintWriter out = response.getWriter();
    	
    	if (!isLoggedIn(session)) {    
    		out.println("<script>");
    		out.println("alert('로그인 후 이용해주세요.');");
    		out.println("window.location.href = 'manager_login.go';"); // location.href 앞에 window 추가.
    		out.println("</script>");
    		out.flush();
        }
    }

    // 관리자 메인 페이지
    @GetMapping("manager_main.go")
    public String managerMain(HttpSession session, HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return null;
        }
        return "parking_management/manager_main";
    }

    // 주차 현황 조회
    @GetMapping("parking_status.go")
    public String parkingStatus(Model model, HttpSession session, HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return null;
        }

        List<ParkingDTO> parkingList = mapper.pList();
        List<ParkingRecordDTO> parkingRecords = mapper.parkingRecords();

        model.addAttribute("parkingList", parkingList)
        	.addAttribute("parkingRecords", parkingRecords);

        return "parking_management/parking_status";
    }

    // 회원 관리
    @GetMapping("user_management.go")
    public String userManage(@RequestParam(value = "page", defaultValue = "1") int page, 
                             Model model, 
                             HttpSession session,
                             HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return null;
        }

        totalRecord = this.mapper.ucount();

        Page pdto = new Page(page, userRowsize, totalRecord);
        List<UsersDTO> userList = this.mapper.userList(pdto);

        model.addAttribute("userList", userList)
             .addAttribute("paging", pdto);

        return "parking_management/user_management";
    }


    // 회원 등록 폼
    @GetMapping("user_registration.go")
    public String userRegistration(HttpSession session, HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return null;
        }
        return "parking_management/user_registration";
    }

    // 회원 등록 처리
    @PostMapping("user_registration_ok.go")
    public void userRegistrationOk(UsersDTO udto, HttpSession session, HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return;
        }

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        UsersDTO user_check = mapper.user_info(udto.getUser_car_num());

        if (user_check != null) {
            out.println("<script>");
            out.println("alert('이미 등록된 차량번호입니다.');");
            out.println("history.back();");
            out.println("</script>");
        } else {
            int reg_user = mapper.registration_user(udto);

            if (reg_user > 0) {
                out.println("<script>");
                out.println("alert('회원을 등록하였습니다.');");
                out.println("location.href='user_management.go';");
                out.println("</script>");
            } else {
                out.println("<script>");
                out.println("alert('회원 등록 과정 중 오류 발생');");
                out.println("history.back();");
                out.println("</script>");
            }
        }
    }

    // 회원 정보 수정 처리
    @PostMapping("user_modify.go")
    public void userModifyOk(UsersDTO udto, HttpSession session, HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return;
        }

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        int user_modify_chk = mapper.userModify(udto);

        if (user_modify_chk > 0) {
            out.println("<script>");
            out.println("alert('회원 정보 수정을 완료하였습니다.');");
            out.println("location.href='user_management.go';");
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('회원 정보 수정 중 오류 발생');");
            out.println("history.back();");
            out.println("</script>");
        }
    }

    // 회원 삭제 처리
    @GetMapping("user_delete.go")
    public void userDelete(@RequestParam("user_car_num") String user_car_num,
                           HttpSession session,
                           HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return;
        }

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        int user_delete_check = mapper.userDelete(user_car_num);

        if (user_delete_check > 0) {
            out.println("<script>");
            out.println("alert('회원 정보를 삭제하였습니다.');");
            out.println("location.href='user_management.go';");
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('회원 정보 삭제 중 오류 발생');");
            out.println("history.back();");
            out.println("</script>");
        }
    }
    
    // 회원 검색
    @PostMapping("user_search_management.go")
    public String user_search_management(@RequestParam(value = "page", defaultValue = "1") int page,
    		@RequestParam("field") String field, @RequestParam("keyword") String keyword, 
    		Model model, HttpSession session, HttpServletResponse response) throws IOException {
    	
    	if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return null;
        }
    	
    	Map<String, String> map = new HashMap<String, String>();
 		
 		map.put("field", field);
 		map.put("keyword", keyword);
    	
    	totalRecord = this.mapper.userSearchCount(map);
    	
    	Page pdto = new Page(page, userRowsize, totalRecord, field, keyword);
    	
    	List<UsersDTO> user_searchList = this.mapper.userSearchList(pdto);
    	
    	model.addAttribute("user_searchList", user_searchList)
    		.addAttribute("pdto", pdto);
    	
    	return "parking_management/user_search_management";
    }

    // 요금 관리 페이지
    @GetMapping("parking_fee_edit.go")
    public String feeEdit(Model model, HttpSession session, HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return null;
        }

        ParkingFeeDTO fee = mapper.getFee();
        model.addAttribute("fee", fee);
        return "parking_management/parking_fee_edit";
    }

    // 요금 수정 처리
    @PostMapping("parking_fee_update.go")
    public void feeUpdate(ParkingFeeDTO fee, HttpSession session, HttpServletResponse response) throws IOException {
        if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return;
        }

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        int result = mapper.updateFee(fee);

        if (result > 0) {
            out.println("<script>");
            out.println("alert('요금 정책이 수정되었습니다.');");
            out.println("location.href='manager_main.go';");
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('수정 중 오류가 발생했습니다.');");
            out.println("history.back();");
            out.println("</script>");
        }
    }

    
    // 주차 기록 리스트 조회
 	@GetMapping("parking_record_list.go")
 	public String car_list(@RequestParam(value = "page", defaultValue = "1") int page,
 			@RequestParam(value = "list_sort", defaultValue = "rec_num") String sort,
 			HttpSession session, HttpServletResponse response, Model model) throws IOException {
 		
 		 if (!isLoggedIn(session)) {
             sendLoginAlertAndRedirect(session, response);
             return null;
         }
 		
 		totalRecord = this.mapper.count();
 		
 		int amountfee = this.mapper.amountfee();
 		
 	    Page pdto = new Page(page, rowsize, totalRecord, sort);

 	    List<ParkingRecordDTO> carList = mapper.car_list(pdto);
 	    
 	    model.addAttribute("carList", carList)
 	    	.addAttribute("list_sort", sort)
 	    	.addAttribute("paging", pdto)
 	    	.addAttribute("amountfee", amountfee);

 	    return "parking_management/parking_record_list";
 	}
 	
 	
 	// 주차 기록 검색
 	@RequestMapping("parking_record_search.go")
 	public String carlist_search
 		(@RequestParam(value = "page", defaultValue = "1") int page,
 			@RequestParam(value = "list_sort", defaultValue = "rec_num") String sort,
 			@RequestParam("field") String field, 
 			@RequestParam(value = "keyword", required = false) 
 			String keyword, Model model, HttpSession session, HttpServletResponse response) throws IOException {
 		
 		if (!isLoggedIn(session)) {
            sendLoginAlertAndRedirect(session, response);
            return null;
        }
 		
 		Map<String, String> map = new HashMap<String, String>();
 		
 		map.put("field", field);
 		map.put("keyword", keyword);
 		
 		totalRecord = this.mapper.scount(map);
 		
 		Integer amountfee = this.mapper.searchamountfee(map);
 		
 		Page pdto = new Page(page, rowsize, totalRecord, field, keyword, sort);
 		
 		List<ParkingRecordDTO> carsearchList = this.mapper.carlist_search(pdto);
 		
 		model.addAttribute("SearchList", carsearchList)
 			 .addAttribute("list_sort", sort)
 			 .addAttribute("paging", pdto)
 			 .addAttribute("amountfee", amountfee);
 		
 		
 		return "parking_management/parking_record_search";
 		
 	}
 	

}