package com.boot.parking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.parking.model.ManagerDTO;
import com.boot.parking.model.Page;
import com.boot.parking.model.ParkingDTO;
import com.boot.parking.model.ParkingFeeDTO;
import com.boot.parking.model.ParkingMapper;
import com.boot.parking.model.ParkingRecordDTO;
import com.boot.parking.model.UsersDTO;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ManagementController {

	@Autowired
	private ParkingMapper mapper;
	
	
	// 관리자 메인 기능 --------------------------------------------------------
	
	@GetMapping("manager_login.go")
	public String managerMain() {
		return "parking_management/manager_login";
	}
	
	@PostMapping("manager_login_ok")
	public void loginOk(@RequestParam("manager_id") String id,
				@RequestParam("manager_pwd") String pwd, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		ManagerDTO dto = new ManagerDTO();
		
		dto.setManager_id(id);
		dto.setManager_pwd(pwd);
		
		ManagerDTO result = mapper.login(dto);
		
		if(result !=null) {
			
			out.println("<script>");
			out.println("location.href='manager_main.go'");
			out.println("</script>");
			
		}else {
			
			out.println("<script>");
            out.println("alert('아이디 또는 비밀번호가 틀립니다.');");
            out.println("history.back();");
            out.println("</script>");
			
		}
		
	}
	
	@GetMapping("manager_main.go")
	public String managerDetail(){
		
		return "parking_management/manager_main";
		
	}
	
	
	
	// 관리자 메인 기능. --------------------------------------------------------
	
	
	
	// 주차 현황 조회 =======================================================
	
	@GetMapping("manager_detail.go")
	public String managerDetail(Model model){
		
			List<ParkingDTO> parkingList = mapper.pList(); // 현재 주차 현황
			List<ParkingRecordDTO> parkingRecords = mapper.parkingRecords(); // 주차 기록

			model.addAttribute("parkingList", parkingList)
				.addAttribute("parkingRecords", parkingRecords);
			
		
		
		return "parking_management/manager_detail";
		
	}
	
	// 주차 현황 조회 =======================================================
	
	
	
	// 회원 관리 --------------------------------------------------------
	
	@GetMapping("user_management.go")
	public String userManage(Model model) {
		List<UsersDTO> userList = this.mapper.userList();
		
		model.addAttribute("userList", userList);
		
		return "parking_management/user_management";
	}
	
	
	@GetMapping("user_registration.go")
	public String user_registration() {
		
		return "parking_management/user_registration";
	}
	
	
	@PostMapping("user_registration_ok.go")
	public void user_registration_ok(UsersDTO udto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		UsersDTO user_check = this.mapper.user_info(udto.getUser_car_num());
		
		if(user_check != null) {
			out.println("<script>");
            out.println("alert('이미 등록된 차량번호입니다.');");
            out.println("history.back();");
            out.println("</script>");
			
		}else {
			int reg_user = this.mapper.registration_user(udto);
			
			if(reg_user > 0) {
				out.println("<script>");
	            out.println("alert('회원을 등록하였습니다.');");
	            out.println("location.href='user_management.go'");
	            out.println("</script>");
			}else {
				out.println("<script>");
	            out.println("alert('회원 등록 과정 중 오류 발생');");
	            out.println("history.back();");
	            out.println("</script>");
			}
		}
		
	}
	
	@PostMapping("user_modify.go")
	public void user_modify_ok(UsersDTO udto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
	    PrintWriter out = response.getWriter();
	    
	    int user_modify_chk = this.mapper.userModify(udto);
	    
	    if(user_modify_chk > 0) {
	    	out.println("<script>");
	    	out.println("alert('회원 정보 수정을 완료하였습니다.');");
	    	out.println("location.href='user_management.go'");
	    	out.println("</script>");
	    }else {
	    	out.println("<script>");
	    	out.println("alert('회원 정보 수정 중 오류 발생');");
	    	out.println("history.back();");
	    	out.println("</script>");
	    }
		
	}
	
	@GetMapping("user_delete.go")
	public void user_delete(@RequestParam("user_car_num") String user_car_num,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
	    PrintWriter out = response.getWriter();
		
	    int user_delete_check = this.mapper.userDelete(user_car_num);
	    
	    if(user_delete_check > 0) {
	    	out.println("<script>");
	    	out.println("alert('회원 정보를 삭제하였습니다.');");
	    	out.println("location.href='user_management.go'");
	    	out.println("</script>");
	    }{
	    	out.println("<script>");
	    	out.println("alert('회원 정보 삭제 중 오류 발생');");
	    	out.println("history.back();");
	    	out.println("</script>");
	    }
	    
	}
	
	// 회원 관리. --------------------------------------------------------
	
	
	
	// 요금 관리 =======================================================
	
	@GetMapping("parking_fee_edit.go")
	public String feeEdit(Model model) {
	    ParkingFeeDTO fee = mapper.getFee();
	    model.addAttribute("fee", fee);
	    return "parking_management/parking_fee_edit";  // /WEB-INF/views/fee_edit.jsp
	}

	@PostMapping("parking_fee_update.go")
	public void feeUpdate(ParkingFeeDTO fee, HttpServletResponse response) throws IOException {
	    response.setContentType("text/html; charset=UTF-8");
	    PrintWriter out = response.getWriter();
	    
	    int result = mapper.updateFee(fee);
	    
	    if (result > 0) {
	        out.println("<script>");
	        out.println("alert('요금 정책이 수정되었습니다.');");
	        out.println("location.href='manager_main.go'");
	        out.println("</script>");
	    } else {
	        out.println("<script>");
	        out.println("alert('수정 중 오류가 발생했습니다.');");
	        out.println("history.back()");
	        out.println("</script>");
	    }
	}
	
	// 요금 관리. =======================================================
	
	
	
	// 주차 기록 --------------------------------------------------------
	
	// 페이지 변수
	private final int rowsize =10;
	private int totalRecord = 0;
	
	
	@GetMapping("parking_record_list.go")
	public String car_list(@RequestParam(value = "page", defaultValue = "1") int page,
	                       Model model) {
		
		totalRecord = this.mapper.count();
		
		int amountfee = this.mapper.amountfee();
		
	    Page pdto = new Page(page, rowsize, totalRecord);

	    List<ParkingRecordDTO> carList = mapper.car_list(pdto);

	    model.addAttribute("carList", carList);
	    model.addAttribute("paging", pdto);
	    model.addAttribute("amountfee", amountfee);

	    return "parking_management/parking_record_list";
	}
	
	@RequestMapping("parking_record_search.go")
	public String carlist_search
		(@RequestParam(value = "page", defaultValue = "1") int page, 
			@RequestParam("field") String field, 
			@RequestParam(value = "keyword", required = false) 
			String keyword, Model model) {
		
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("field", field);
		map.put("keyword", keyword);
		
		totalRecord = this.mapper.scount(map);
		
		Integer amountfee = this.mapper.searchamountfee(map);
		
		Page pdto = new Page(page, rowsize, totalRecord, field, keyword);
		
		List<ParkingRecordDTO> carsearchList = this.mapper.carlist_search(pdto);
		
		model.addAttribute("SearchList", carsearchList)
			 .addAttribute("paging", pdto)
			 .addAttribute("amountfee", amountfee);
		
		
		return "parking_management/parking_record_search";
		
	}
	
	// 주차 기록. --------------------------------------------------------
	
	
	
}
