package com.boot.parking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.parking.model.CarsDTO;
import com.boot.parking.model.ManagerDTO;
import com.boot.parking.model.Page;
import com.boot.parking.model.ParkingDTO;
import com.boot.parking.model.ParkingMapper;
import com.boot.parking.model.ParkingRecordDTO;
import com.boot.parking.model.UsersDTO;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ParkingController {

	@Autowired
	private ParkingMapper mapper;
	
	// 페이지 변수
	private final int rowsize =10;
	private int totalRecord = 0;
	
	@GetMapping("/")
	public String Mapmain() {
		return "map_main";
	}
	
	@GetMapping("main.go")
	public String Controlmain() {
		
		return "main";
	}
	
	
// 입차 -----------------------------------------------------------
	
	@GetMapping("came_in.go")
	public String in() {
		return "in";
	}
	
	@RequestMapping("parking.go")
	public String parking(@RequestParam("car_num") String car_num,
			Model model, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		CarsDTO car = this.mapper.car(car_num);
		
		if(car == null) {
			if(car_num == "") {
				out.println("<script>");
				out.println("alert('차량번호를 입력하세요.')");
				out.println("history.back()");
				out.println("</script>");
				
				return null;
			}
			
			List<ParkingDTO> plist = this.mapper.pList();
			int A_count = this.mapper.A_section_conut();
			int B_count = this.mapper.B_section_conut();
			
			model.addAttribute("plist", plist)
				.addAttribute("car_num", car_num)
				.addAttribute("A_count", A_count)
				.addAttribute("B_count", B_count);
			
			return "parking";
			
		}else {
			out.println("<script>");
			out.println("alert('이미 주차 되어있는 차량입니다.')");
			out.println("history.back()");
			out.println("</script>");
			
			return null;
		}
		
	}
	
	@GetMapping("parking_ok.go")
	public void parking_ok(ParkingDTO pdto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		ParkingRecordDTO rdto = new ParkingRecordDTO();
		
		int check = this.mapper.in_car(pdto.getCar_num());
		
		if(check > 0) {
			int chk = this.mapper.parking(pdto);
			
			if(chk > 0) {
				UsersDTO user = this.mapper.user_info(pdto.getCar_num());
				CarsDTO car = this.mapper.car_info(pdto.getCar_num());
				
				if(user == null) {
					rdto.setUser_id("");
				}else {
					rdto.setUser_id(user.getUser_id());
				}
				
				rdto.setCar_num(car.getCar_num());
				rdto.setIn_time(car.getIn_time());
				rdto.setOut_time(null); // 출차 시간은 아직 없으므로 null
	            rdto.setFee_amount(0);
				
				this.mapper.record_in(rdto);
				
				out.println("<script>");
				out.println("alert('주차 완료')");
				out.println("location.href='/'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('오류 발생')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			out.println("<script>");
			out.println("alert('오류 발생(2)')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
// 입차. -----------------------------------------------------------

	
	
// 출차 -----------------------------------------------------	-------
	
	@GetMapping("went_out.go")
	public String went_out() {
		return "out";
	}
	
	@PostMapping("went_out_ok.go")
	public void went_out_ok(@RequestParam("car_num") String car_num,
	                        HttpServletResponse response) throws IOException {

	    response.setContentType("text/html; charset=UTF-8");
	    PrintWriter out = response.getWriter();

	    Date inTime = mapper.selectInTimeByCarNum(car_num);

	    if (inTime == null) {
	        out.println("<script>");
	        out.println("alert('입차 기록이 없습니다.');");
	        out.println("history.back();");
	        out.println("</script>");
	        return;
	    }

	    Date outTime = new Date();

	    long millis = outTime.getTime() - inTime.getTime();
	    long minutes = millis / (1000 * 60);

	    int fee = 0;
	    if (minutes > 30) {
	        fee = (int) (((minutes - 30) / 10) + 1) * 1000;
	    }

	    // parking_record 조회해서 PK 가져오기 (별도 메서드 필요)
	    int parkingRecNum = mapper.selectRecordNumByCarNumAndInTime(car_num, inTime);
	    if (parkingRecNum == 0) {
	        out.println("<script>");
	        out.println("alert('주차 기록이 없습니다.');");
	        out.println("history.back();");
	        out.println("</script>");
	        return;
	    }

	    ParkingRecordDTO record = new ParkingRecordDTO();
	    record.setParking_rec_num(parkingRecNum);
	    record.setCar_num(car_num);
	    record.setIn_time(inTime);
	    record.setOut_time(outTime);
	    record.setFee_amount(fee);

	    int updateCount = mapper.record_out(record);

	    if (updateCount > 0) {
	        int delParking = mapper.out(car_num);           // parking 테이블 car_num null 처리

	        if (delParking > 0) {
	            out.println("<script>");
	            out.println("alert('출차 완료. 요금: " + fee + "원');");
	            out.println("location.href='/'");
	            out.println("</script>");
	        } else {
	            out.println("<script>");
	            out.println("alert('출차 처리 오류');");
	            out.println("history.back();");
	            out.println("</script>");
	        }
	    } else {
	        out.println("<script>");
	        out.println("alert('주차 기록 업데이트 실패');");
	        out.println("history.back();");
	        out.println("</script>");
	    }
	}
	
// 출차. -----------------------------------------------------------	
	
	
// 차량 조회 --------------------------------------------------------

	@GetMapping("search_car.go")
	public String search_car() {
		return "search_car";
	}
	
	
	@PostMapping("search_car_ok.go")
	public String search_car_ok(@RequestParam("car_num") String car_num,
			HttpServletResponse response, Model model) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String parking_id = this.mapper.search_car(car_num);
		List<ParkingDTO> plist = this.mapper.pList();
		
		
		
		model.addAttribute("parking_id", parking_id)
			.addAttribute("plist", plist);
		
		String res = null;
		
		if(parking_id != null) {
			res = "search_car_ok";
		}else {
			out.println("<script>");
			out.println("alert('조회된 차량번호가 존재하지 않습니다.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return res;
		
	}
	
// 차량 조회. --------------------------------------------------------
	
	
	
// 주차 기록 ---------------------------------------------------------
	
	@GetMapping("list_car.go")
	public String car_list(@RequestParam(value = "page", defaultValue = "1") int page,
	                       Model model) {
		
		totalRecord = this.mapper.count();
		
	    Page pdto = new Page(page, rowsize, totalRecord);

	    List<ParkingRecordDTO> carList = mapper.car_list(pdto);

	    model.addAttribute("carList", carList);
	    model.addAttribute("paging", pdto);

	    return "list";
	}
	
	
	@RequestMapping("carlist_search.go")
	public String carlist_search
		(@RequestParam(value = "page", defaultValue = "1") int page, 
			@RequestParam("field") String field, 
			@RequestParam(value = "keyword", required = false) 
			String keyword, Model model) {
		
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("field", field);
		map.put("keyword", keyword);
		
		totalRecord = this.mapper.scount(map);
		
		Page pdto = new Page(page, rowsize, totalRecord, field, keyword);
		
		List<ParkingRecordDTO> carsearchList = this.mapper.carlist_search(pdto);
		
		model.addAttribute("SearchList", carsearchList)
			 .addAttribute("paging", pdto);
		
		
		return "carlist_search";
		
	}
	
// 주차 기록. ---------------------------------------------------------
	
// 관리 ------------------------------------------------------------
	
	@GetMapping("manager_main.go")
	public String managerMain() {
		return "manager_main";
	}
	
	@PostMapping("login_ok")
	public void loginOk(@RequestParam("manager_id") String id,
				@RequestParam("manager_pwd") String pwd, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		ManagerDTO dto = new ManagerDTO();
		
		dto.setManager_id(id);
		dto.setManager_pwd(pwd);
		
		ManagerDTO result = mapper.login(dto);
		
		if(result !=null) {
			
			out.println("<script>");
			out.println("alert('로그인성공!!')");
			out.println("location.href='manager_home.go'");
			out.println("</script>");
			
		}else {
			
			out.println("<script>");
            out.println("alert('아이디 또는 비밀번호가 틀립니다.');");
            out.println("history.back();");
            out.println("</script>");
			
		}
		
	}
	
	@GetMapping("manager_home.go")
	public String managerDetail(){
		
		return "manager_home";
		
	}
	
	@GetMapping("manager_detail.go")
	public String managerDetail(Model model){
		
			List<ParkingDTO> parkingList = mapper.pList(); // 현재 주차 현황
			List<ParkingRecordDTO> parkingRecords = mapper.parkingRecords(); // 주차 기록

			model.addAttribute("parkingList", parkingList)
				.addAttribute("parkingRecords", parkingRecords);
		
		return "manager_detail";
		
	}
	
	@GetMapping("user_management.go")
	public String userManage(Model model) {
		List<UsersDTO> userList = this.mapper.userList();
		
		model.addAttribute("userList", userList);
		
		return "user_management";
	}
	
	
	@GetMapping("user_registration.go")
	public String user_registration() {
		
		return "user_registration";
	}
	
	
	@PostMapping("user_registration_ok.go")
	public void user_registration_ok(UsersDTO udto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		UsersDTO user_check = this.mapper.user_info(udto.getUser_car_num());
		
		if(user_check != null) {
			out.println("<script>");
            out.println("alert('이미 등록된 차량번호입니다.');");
            out.println("history.back();");
            out.println("</script>");
			
		}else {
			int reg_user = this.mapper.registration_user(udto);
			
			if(reg_user > 0) {
				out.println("<script>");
	            out.println("alert('회원을 등록하였습니다.');");
	            out.println("location.href='manager_detail.go'");
	            out.println("</script>");
			}else {
				out.println("<script>");
	            out.println("alert('회원 등록 과정 중 오류 발생');");
	            out.println("history.back();");
	            out.println("</script>");
			}
		}
		
	}

// 관리. -----------------------------------------------------------
	
	
	@GetMapping("map_view.go")
	public String maptest() {
		
		
		return "map_view";
		
	}
	
	
	
}
