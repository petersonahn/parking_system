<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>센트럴 파크 빌딩 주차장 </title>
</head>
<body>

	<h1>주차 시스템 홈페이지</h1>

<!-- 메뉴 버튼 -->
	<div>
		<button onclick="location.href='parking_facility.jsp'">주차시설</button>
		<button onclick="location.href='main.go'">주차관리</button>
		

	</div>

	<div style="margin-top: 30px;">
		<button>주차장 위치</button>
	</div>

<!-- 지도 사이즈 및 위치 설정 -->

		
	<div id="googleMap" style="width: 600px; height: 400px;" margin-top: 10px; ></div> 
		
		
	<script>
	function initMap() {
		const CentPlz = { lat: 37.658259, lng: 126.773349 };  // 위도 , 경도 위치설정

		const mapOptions = {    // 처음 띄워지는 지도의 위치 설정
			center: CentPlz,
			zoom: 15
		};

		const map = new google.maps.Map(document.getElementById("googleMap"), mapOptions);

		// 마커 추가
		const marker = new google.maps.Marker({
			position: CentPlz,
			map: map,
			title: "센트럴 파크 빌딩 주차장"
		});
	}
	</script>
	


	<script 
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC6GZL5JoPGTDsQqjhGD-dgKj7hRQSTxfE&callback=initMap" 
  async defer> 
	</script>

</body>
</html>
