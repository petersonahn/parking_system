<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
		
		$("form").submit(function(e) {
			
			if($("#user_car_num").val().trim() === "") {
				alert("차량 번호를 입력하세요.");
				$("#user_car_num").focus();
				e.preventDefault();
			}
			
			else if($("#user_id").val().trim() === "") {
				alert("회원 아이디를 입력하세요.");
				$("#user_id").focus();
				e.preventDefault();
			}
			
			else if($("#user_name").val().trim() === "") {
				alert("회원 이름을 입력하세요.");
				$("#user_name").focus();
				e.preventDefault();
			}
			
			else if($("#user_phone").val().trim() === "") {
				alert("회원 연락처를 입력하세요.");
				$("#user_phone").focus();
				e.preventDefault();
			}
			
		});
		
	});
	
</script>
<title>Insert title here</title>
</head>
<body>
	
	<div>
		<form method="post" action="<%=request.getContextPath() %>/user_registration_ok.go">
			<div>
				<table border="1">
					<tr>
						<th>차량 번호</th>
						<td><input id="user_car_num" name="user_car_num"></td>
					</tr>
				
					<tr>
						<th>회원 아이디</th>
						<td><input id="user_id" name="user_id"></td>
					</tr>
					
					<tr>
						<th>회원 이름</th>
						<td><input id="user_name" name="user_name"></td>
					</tr>
					
					<tr>
						<th>회원 연락처</th>
						<td><input id="user_phone" name="user_phone"></td>
					</tr>
				</table>
			</div>
			
			<div class="button">
				<button type="submit">등록</button>
				<button type="reset" onclick="location.href='user_management.go'">취소</button>
			</div>
		</form>
	</div>
	
</body>
</html>