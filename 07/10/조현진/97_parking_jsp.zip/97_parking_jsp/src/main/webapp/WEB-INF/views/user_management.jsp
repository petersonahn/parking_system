<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

	<div>
		<c:set var="uList" value="${userList }" />
		
		<div class="list">
			<table border="1">
				<tr>
					<th>회원 번호</th>
					<th>차량 번호</th>
					<th>회원 이름</th>
					<th>회원 연락처</th>
				</tr>
				
				<c:forEach var="user" items="${uList }">
					<tr>
						<td>${user.getUser_id() }</td>
						<td>${user.getUser_car_num() }</td>
						<td>${user.getUser_name() }</td>
						<td>${user.getUser_phone() }</td>
					</tr>
				</c:forEach>
			</table>
		</div>
		<br>
		
		<div class="button">
			<button onclick="location.href='user_registration.go'">회원 등록</button>
			<button onclick="location.href='user_modify.go'">회원 정보 수정</button>
			<button onclick="location.href='#'">회원 정보 삭제</button>
		</div>
	</div>

</body>
</html>