<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>

    .pagination a {
		margin: 0 5px;
      	text-decoration: none;
      	color: black;
    }
    .pagination .active {
      	font-weight: bold;
      	color: black;
    }
    
</style>

<script>
	const fieldSelect = document.querySelector('select[name="field"]');
	const textInput = document.getElementById("keywordInput");
	const dateInput = document.getElementById("dateInput");
	
	fieldSelect.addEventListener("change", function () {
		const value = this.value;
	
	    const isDate = value === "in_time";
	    const isParking = value === "parking";
	
	    // 1. 보여줄 인풋 설정
	    textInput.style.display = (!isDate && !isParking) ? "inline-block" : "none";
	    dateInput.style.display = isDate ? "inline-block" : "none";
	
	    // 2. name 속성 설정 → 서버로 keyword 1개만 전송되도록
	    textInput.name = (!isDate && !isParking) ? "keyword" : "temp";
	    dateInput.name = isDate ? "keyword" : "temp";
	});
</script>

<title>차량 리스트</title>
  
</head>
<body>

	<div align="center">
	  	<h2>주차 기록 조회</h2>
	  	<br>
	  
	   	<form method="post" action="<%=request.getContextPath() %>/carlist_search.go">
		   
			<select name="field">
		    	<option value="car_num">차량 번호</option>
		        <option value="in_time">입차 시간</option>
		        <option value="parking">주차중 차량</option>
		    </select>
		      
			<input type="text" name="keyword" id="keywordInput">
			<input type="date" name="temp" id="dateInput" style="display: none;"> <!-- 날짜 필드 -->
	
	  		&nbsp;&nbsp;&nbsp;
	  		<input type="submit" value="검색">
		</form>
	
		<br>
		<h5>차량 대수: ${paging.totalRecord }대</h5>
	
	  	<table border="1" width="30%">
		    <tr>
		    	<th>차량 번호</th>
		      	<th>입차 시간</th>
		      	<th>출차 시간</th>
		    </tr>
	
	      	<c:set var="list" value="${carList}" />
	      	
	      	<c:if test="${!empty list }">
		    	<c:forEach var="car" items="${list}">
					<tr>
						<td>${car.car_num}</td>
				        <td><fmt:formatDate value="${car.in_time}" pattern="yyyy-MM-dd HH:mm"/></td>
				        <td>
				        	<c:choose>
					        	<c:when test="${empty car.out_time}">
					            	<span style="color:red;">주차중</span>
					            </c:when>
					            
					            <c:otherwise>
					             	<fmt:formatDate value="${car.out_time}" pattern="yyyy-MM-dd HH:mm"/>
					            </c:otherwise>
					        </c:choose>
					 	</td>
					</tr>
		   		</c:forEach>
	    	</c:if>
	    
	    	<c:if test="${empty list }">
	        	<tr>
		            <td colspan="4" align="center">
		            	<h3>차량 리스트가 없습니다.....</h3>
		            </td>
	         	</tr>
		   	</c:if>
		 
		</table>
		<br>
	  
	  	<!-- 페이징 버튼 영역 -->
	  	<c:if test="${paging.page > paging.block }">
	  		<a href="list_car.go?page=1">[맨 처음]</a>
		    <a href="list_car.go?page=${paging.startBlock - 1 }">◀</a>
		</c:if>
		  
		<c:forEach begin="${paging.startBlock}" end="${paging.endBlock}" var="i">
	  		<c:if test="${i == paging.page}">
	    		<b><a href="list_car.go?page=${i}">[${i}]</a></b>
	  		</c:if>
	  		
	 		<c:if test="${i != paging.page}">
	    		<a href="list_car.go?page=${i}">[${i}]</a>
	  		</c:if>
		</c:forEach>
	
		<c:if test="${paging.endBlock < paging.allPage}">
	  		<a href="list_car.go?page=${paging.endBlock + 1}">▶</a>
	  		<a href="list_car.go?page=${paging.allPage}">[맨 마지막]</a>
		</c:if>
	
	</div>  

</body>
</html>
