<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>

	.pagination a {
		margin: 0 5px;
      	text-decoration: none;
      	color: black;
    }
    
    .pagination .active {
    	font-weight: bold;
      	color: black;
    }
    
 </style>
<title>Insert title here</title>
</head>
<body>

	<c:set var="paging" value="${paging }" /> 
	
	<div align="center">
	  	<h2>검색 차량 리스트</h2>
	  	<br>
	  	<h5>검색된 차량 대수 : ${paging.totalRecord }대</h5>
	
	  	<table border="1" width="30%">
		    <tr>
		      	<th>차량번호</th>
		      	<th>입차시간</th>
		      	<th>출차시간</th>
		    </tr>
	
	      	<c:set var="list" value="${SearchList}" />
	      
	      	<c:if test="${!empty list }">
		         	      
		    	<c:forEach var="car" items="${list}">
		      		<tr>
		        		<td>${car.car_num}</td>
		        		<td><fmt:formatDate value="${car.in_time}" pattern="yyyy-MM-dd HH:mm"/></td>
		        		<td>
		          			<c:choose>
		            			<c:when test="${empty car.out_time}">
		              				<span style="color:red;">주차중</span>
		            			</c:when>
		            			
		            			<c:otherwise>
		              				<fmt:formatDate value="${car.out_time}" pattern="yyyy-MM-dd HH:mm"/>
		            			</c:otherwise>
		          			</c:choose>
		        		</td>
		      		</tr>
		    	</c:forEach>
	      	</c:if>
	    
	    	<c:if test="${empty list }">
		    	<tr>
		        	<td colspan="4" align="center">
		              	<h3>차량 리스트가 없습니다.....</h3>
		            </td>
		        </tr>
		   	</c:if>
		      
		</table>
		<br>
	 
	 	<!-- 페이징 버튼 영역 -->
	 	<c:if test="${paging.page > paging.block }">
		  	<a href="<%=request.getContextPath() %>/carlist_search.go?page=1&field=${paging.field}&keyword=${paging.keyword}">[맨 처음]</a>
		    <a href="<%=request.getContextPath() %>/carlist_search.go?page=${paging.startBlock - 1 }&field=${paging.field}&keyword=${paging.keyword}">◀</a>
		</c:if>
		  
		<c:forEach begin="${paging.startBlock}" end="${paging.endBlock}" var="i">
	  		<c:if test="${i == paging.page}">
	    		<b><a href="<%=request.getContextPath() %>/carlist_search.go?page=${i}&field=${paging.field}&keyword=${paging.keyword}">[${i}]</a></b>
	  		</c:if>
	  		
	  		<c:if test="${i != paging.page}">
	    		<a href="<%=request.getContextPath() %>/carlist_search.go?page=${i}&field=${paging.field}&keyword=${paging.keyword}">[${i}]</a>
	  		</c:if>
		</c:forEach>
	
		<c:if test="${paging.endBlock < paging.allPage}">
	  		<a href="<%=request.getContextPath() %>/carlist_search.go?page=${paging.endBlock + 1}&field=${paging.field}&keyword=${paging.keyword}">▶</a>
	  		<a href="<%=request.getContextPath() %>/carlist_search.go?page=${paging.allPage}&field=${paging.field}&keyword=${paging.keyword}">[맨 마지막]</a>
		</c:if>
	
		<button onclick="location.href='list_car.go'">돌아가기</button>
	
	</div> 

</body>
</html>