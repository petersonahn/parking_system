<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
	body {
		background-color: #eaf3fb;
		font-family: 'Segoe UI', '맑은 고딕', sans-serif;
		margin: 0;
		padding: 0;
	}

	.car-num-box {
		margin: 30px auto 10px;
		padding: 15px 25px;
		font-size: 24px;
		font-weight: bold;
		color: #222;
		background-color: #fff;
		border: 2px solid #3498db;
		border-radius: 10px;
		box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
		width: fit-content;
		text-align: center;
	}

	h1 {
		text-align: center;
		color: #2d6ac0;
		margin-top: 20px;
		font-weight: 700;
	}

	.list {
		display: flex;
		justify-content: center;
		gap: 30px;
		padding: 40px 20px;
		flex-wrap: wrap;
	}

	table {
		border-collapse: collapse;
		border: 1px solid #ccc;
		border-radius: 10px;
		overflow: hidden;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
		background-color: #fff;
	}

	td {
		width: 60px;
		height: 50px;
		text-align: center;
		font-weight: bold;
		font-size: 15px;
		border: 1px solid #ddd;
	}

	.on {
		background-color: skyblue;
		color: #000;
		border: 2px solid #3498db;
		box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
	}

	.off {
		background-color: #f1f1f1;
		color: #aaa;
	}
</style>
<title>Insert title here</title>
</head>
<body>

	<c:set var="car_location" value="${parking_id }" />

	<div>
		<h1>조회된 차량의 위치는 '${car_location }' 입니다.</h1>
	</div>

	<div class="list">
		
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
				
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index < 10}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 9 and status.index < 20}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 19 and status.index < 30}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 29 and status.index < 40}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 39 and status.index < 50}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
	</div>
	<br>
	
	<div class="btn">
		<button onclick="location.href='/'">메인</button>
	</div>

</body>
</html>