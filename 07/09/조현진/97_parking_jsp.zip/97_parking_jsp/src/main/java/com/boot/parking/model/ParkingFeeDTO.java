package com.boot.parking.model;

import java.util.Date;
import lombok.Data;

@Data
public class ParkingFeeDTO {
	private String car_num;
    private Date in_time;
    private Date out_time;
    private int fee_amount;
}
