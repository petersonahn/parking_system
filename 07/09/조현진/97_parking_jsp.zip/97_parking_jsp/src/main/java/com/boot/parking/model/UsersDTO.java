package com.boot.parking.model;

import lombok.Data;

@Data
public class UsersDTO {

	private String user_id;
	private String user_car_num;
	private String user_name;
	private String user_phone; 
	
}
