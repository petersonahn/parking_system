package com.boot.parking.model;

import lombok.Data;
import java.util.Date;

@Data
public class ParkingRecordDTO {

	private Integer parking_rec_num;
	private String car_num;
	private Date in_time;
	private Date out_time;
	private String user_id;
	private int fee_amount;      // 새로 추가된 요금 필드
	
}
