package com.boot.parking.model;

import java.util.List;
import java.util.Date;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ParkingMapper {
	
	ManagerDTO login(ManagerDTO dto); // 관리자 로그인

	List<ParkingDTO> pList();
	
	String search_car(String car_num);
	
	int in_car(String car_num);
	
	int parking(ParkingDTO pdto);
	
	int out_time_update(String car_num);
	
	int out(String car_num);
	
	CarsDTO car_info(String car_num);
	
	UsersDTO user_info(String car_num);
	
	int record_in(ParkingRecordDTO rdto);
		
	
	List<ParkingRecordDTO> car_list();
	
	// 입차 시간 조회
	Date selectInTimeByCarNum(String car_num);
	
	// 기존의 record_out 대신 out_time과 fee_amount를 통합 관리하는 메서드
	int record_out(ParkingRecordDTO record);

	// 출차 시 주차기록의 PK를 조회하는 메서드
    int selectRecordNumByCarNumAndInTime(@Param("car_num") String car_num, @Param("in_time") Date in_time);

	
	int deleteCarByCarNum(String car_num);
	
	// 주차 기록
	List<ParkingRecordDTO> car_list(Page pdto);

	int count();
}
