<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<html>
<head>
	<title>Home</title>
</head>
<body>
    <div align="center">
	   <hr width="30%" color="gray">
	      <h3>BOARD 테이블 메인 페이지</h3>
	   <hr width="30%" color="gray">
	   <br> <br>
	   
	   <a href="<%=request.getContextPath() %>/board_list.go">[전체 게시물 목록]</a>
	</div>
</body>
</html>