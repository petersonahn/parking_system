<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<%-- 메서드(함수)를 모아 놓은 디렉티브 --%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<%

	request.setAttribute("newLine", "\r\n");
	request.setAttribute("br", "<br>");

%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

	<div align="center">
	   <c:set var="board" value="${Cont }" />
	   <hr width="30%" color="blue">
	      <h3> ${board.board_writer } 님 게시글 상세 정보 페이지</h3>
	   <hr width="30%" color="blue">
	   <br> <br>
	   
	   <table border="1" width="500">
	      <tr>
	         <th>게시글 No.</th>
	         <td> ${board.board_no } </td>
	         
	         <th>작성자</th>
	         <td> ${board.board_writer } </td>
	      </tr>
	      
	      <tr>
	         <c:if test="${empty board.board_redate }">
	         	<th>작성일자</th>
	         	<td> ${board.board_date } </td>
	         </c:if>
	      
	         <c:if test="${!empty board.board_redate }">
	         	<th>수정일자</th>
	         	<td> ${board.board_redate } </td>
	         </c:if>
	      
	         <th>조회수</th>
	         <td> ${board.board_hit } </td>  
	      </tr>
	      
	      <tr>
	         <th>글 제목</th>
	         <td colspan="3" align="center">
	            ${board.board_title }
	         </td>
	      </tr>
	      
	      <tr>
	         <th>글 내용</th>
	         <td colspan="3" align="center">
	            ${fn:replace(board.board_cont, newLine, br) }
	         </td>
	      </tr>
	      
	      <tr>
	         <th>글 비밀번호</th>
	         <td colspan="3" align="center">
	            <c:forEach begin="1" end="${board.board_pwd.length() }">
	            		*
	            </c:forEach>
	         </td>
	      </tr>
	      
	      <c:if test="${empty board }">
	         <tr>
	            <td colspan="7" align="center">
	               <h3>게시글 번호에 해당하는 게시글이 없습니다.....</h3>
	            </td>
	         </tr>
	      </c:if>
	   </table>
	   <br> <br>
	   
	   <input type="button" value="글수정"
	      onclick="location.href='board_modify.go?no=${board.board_no}'">
	   
	   <input type="button" value="글삭제"
	      onclick="if(confirm('게시글을 정말로 삭제하시겠습니까?')) {
	      			  location.href='board_delete.go?no=${board.board_no}'
	      		   }else { return; }">
	      
	   <input type="button" value="글목록"
	      onclick="location.href='board_list.go'">
	
	</div>
	
</body>
</html>