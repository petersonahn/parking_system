<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
	
</head>
<body>
		<h3>현재 주차 현황</h3>
		<!-- HTML 내부 -->
			<table border="1">
			  <tr>
			    <th>주차구역 ID</th>
			    <th>차량번호</th>
			  </tr>
			  <c:forEach var="p" items="${parkingList}">
			    <tr>
			      <td>${p.parking_id}</td>
			      <td>
			        <c:choose>
			          <c:when test="${p.car_num != null}">
			            <span onclick="showModal('${p.car_num}')" style="color:blue; cursor:pointer;">
			              ${p.car_num}
			            </span>
			          </c:when>
			          <c:otherwise>비어있음</c:otherwise>
			        </c:choose>
			      </td>
			    </tr>
			  </c:forEach>
			</table>
			
			<!-- 모달창 HTML  -->
			<div id="modal" style="display:none; position:fixed; left:0; top:0; width:100%; height:100%; background:#00000088;">
			  <div style="background:white; width:500px; margin:100px auto; padding:20px; border-radius:10px;">
			    <button onclick="hideModal()" style="float:right;">닫기</button>
			    <h3>차량 입출차 기록</h3>
			    <div id="recordTable"></div>
			  </div>
			</div>
			
			<!-- JS 데이터 전달 -->
			<script>
			  const records = [
			    <c:forEach var="r" items="${parkingRecords}" varStatus="vs">
			    {
			      num: "${r.parking_rec_num}",
			      car: "${r.car_num}",
			      in: "${r.in_time}",
			      out: "${r.out_time != null ? r.out_time : '출차 전'}",
			      user: "${r.user_id}"
			    }<c:if test="${!vs.last}">,</c:if>
			    </c:forEach>
			  ];
			
			  function showModal(carNum) {
			    	const list = records.filter(r => r.car === carNum);
			   			 let html = `<table border="1" width="100%">
			     		 <tr><th>기록번호</th><th>입차</th><th>출차</th><th>회원</th></tr>`;
			   			 list.forEach(r => {
			     			 html += `<tr>
			       		 <td>${r.num}</td><td>${r.in}</td><td>${r.out}</td><td>${r.user}</td>
			     		 </tr>`;
			    });
			   		 html += `</table>`;
			   	 document.getElementById('recordTable').innerHTML = html;
			   	 document.getElementById('modal').style.display = 'block';
			  }
			
			  function hideModal() {
			   	 document.getElementById('modal').style.display = 'none';
			  }
			  
			  
			</script>

	
		
</body>
</html>