package com.boot.parking.model;

import java.util.List;
import java.util.Date;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ParkingMapper {

	List<ParkingDTO> pList();
	
	String search_car(String car_num);
	
	int in_car(String car_num);
	
	int parking(ParkingDTO pdto);
	
	int out_time_update(String car_num);
	
	int out(String car_num);
	
	CarsDTO car_info(String car_num);
	
	UsersDTO user_info(String car_num);
	
	void record_in(ParkingRecordDTO rdto);
	
	// 입차 시간 조회
	Date selectInTimeByCarNum(String car_num);

	// 출차 내역 insert
	int insertParkingFee(ParkingFeeDTO pfDto);

	// 출차 내역 update
	int updateParkingFee(ParkingFeeDTO pfDto);
	
	// 관리자 로그인
	ManagerDTO login(ManagerDTO dto); 
	
	// 주차 기록 조회
	List<ParkingRecordDTO> parkingRecords();
	
	//
}
