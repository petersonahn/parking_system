package com.boot.parking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.parking.model.CarsDTO;
import com.boot.parking.model.ManagerDTO;
import com.boot.parking.model.ParkingDTO;
import com.boot.parking.model.ParkingFeeDTO;
import com.boot.parking.model.ParkingMapper;
import com.boot.parking.model.ParkingRecordDTO;
import com.boot.parking.model.UsersDTO;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ParkingController {

	@Autowired
	private ParkingMapper mapper;
	
	@GetMapping("/")
	public String main() {
		return "main";
	}
	
	@GetMapping("came_in.go")
	public String in() {
		return "in";
	}
	
	@RequestMapping("parking.go")
	public String parking(@RequestParam("car_num") String car_num,
			Model model, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		if(car_num == "") {
			out.println("<script>");
			out.println("alert('차량번호를 입력하세요.')");
			out.println("history.back()");
			out.println("</script>");
			
			return null;
		}
		
		List<ParkingDTO> plist = this.mapper.pList();
		model.addAttribute("plist", plist)
			.addAttribute("car_num", car_num);
		
		return "parking";
	}
	
	@GetMapping("parking_ok.go")
	public void parking_ok(ParkingDTO pdto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		ParkingRecordDTO rdto = new ParkingRecordDTO();
		
		int check = this.mapper.in_car(pdto.getCar_num());
		
		if(check > 0) {
			int chk = this.mapper.parking(pdto);
			
			if(chk > 0) {
				UsersDTO user = this.mapper.user_info(pdto.getCar_num());
				CarsDTO car = this.mapper.car_info(pdto.getCar_num());
				
				if(user == null) {
					rdto.setUser_id("");
				}else {
					rdto.setUser_id(user.getUser_id());
				}
				
				rdto.setCar_num(car.getCar_num());
				rdto.setIn_time(car.getIn_time());
				
				this.mapper.record_in(rdto);
				
				out.println("<script>");
				out.println("alert('주차 완료')");
				out.println("location.href='/'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('오류 발생')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			out.println("<script>");
			out.println("alert('오류 발생(2)')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@GetMapping("went_out.go")
	public String went_out() {
		return "out";
	}
	
	@PostMapping("went_out_ok.go")
	public void went_out_ok(@RequestParam("car_num") String car_num,
	                        HttpServletResponse response) throws IOException {

	    response.setContentType("text/html; charset=UTF-8");
	    PrintWriter out = response.getWriter();

	    // 1. 입차 시간 조회
	    Date inTime = mapper.selectInTimeByCarNum(car_num);

	    if(inTime == null) {
	        out.println("<script>");
	        out.println("alert('입차 기록이 없습니다.');");
	        out.println("history.back();");
	        out.println("</script>");
	        return;
	    }

	    // 2. 출차 시간 = 현재 시간
	    Date outTime = new Date();

	    // 3. 주차 시간 계산 (분 단위)
	    long Millis = outTime.getTime() - inTime.getTime();
	    long Minutes = Millis / (1000 * 60);

	    // 4. 요금 계산 예시
	    int fee = 0;
	    if(Minutes > 30) {  // 30분 무료
	        fee = (int) (((Minutes - 30) / 10) + 1) * 1000;  // 10분당 1000원
	    }

	    // 5. 출차 내역 객체 생성
	    ParkingFeeDTO pfDto = new ParkingFeeDTO();
	    pfDto.setCar_num(car_num);
	    pfDto.setIn_time(inTime);
	    pfDto.setOut_time(outTime);
	    pfDto.setFee_amount(fee);

	    // 6. 출차 내역 insert or update (기존 출차 내역이 없으면 insert)
	    int resInsert = mapper.insertParkingFee(pfDto);
	    if(resInsert < 1) {
	        // 이미 존재하면 update
	        mapper.updateParkingFee(pfDto);
	    }

	    // 7. cars 테이블 출차 시간 업데이트
	    int updateCount = mapper.out_time_update(car_num);

	    if(updateCount > 0) {
	        // 8. parking 테이블 출차 처리 (주차 공간 비우기)
	        int deleteCount = mapper.out(car_num);

	        if(deleteCount > 0) {
	            out.println("<script>");
	            out.println("alert('출차 처리 완료. 요금: " + fee + "원');");
	            out.println("location.href='/'");
	            out.println("</script>");
	        } else {
	            out.println("<script>");
	            out.println("alert('주차 공간 비우기 오류');");
	            out.println("history.back();");
	            out.println("</script>");
	        }
	    } else {
	        out.println("<script>");
	        out.println("alert('출차 시간 업데이트 오류');");
	        out.println("history.back();");
	        out.println("</script>");
	    }
	}
	
	
	@GetMapping("search_car.go")
	public String search_car() {
		return "search_car";
	}
	
	
	@PostMapping("search_car_ok.go")
	public String search_car_ok(@RequestParam("car_num") String car_num,
			HttpServletResponse response, Model model) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String parking_id = this.mapper.search_car(car_num);
		List<ParkingDTO> plist = this.mapper.pList();
		
		
		
		model.addAttribute("parking_id", parking_id)
			.addAttribute("plist", plist);
		
		String res = null;
		
		if(parking_id != null) {
			res = "search_car_ok";
		}else {
			out.println("<script>");
			out.println("alert('조회된 차량번호가 존재하지 않습니다.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return res;
		
		
	}
	
	
	@GetMapping("manager_main.go")
	public String managerMain() {
		return "manager_main";
	}
	
	@PostMapping("login_ok")
	public void loginOk(@RequestParam("manager_id") String id,
				@RequestParam("manager_pwd") String pwd, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		ManagerDTO dto = new ManagerDTO();
		
		
		dto.setManager_id(id);
		dto.setManager_pwd(pwd);
		
		ManagerDTO result = mapper.login(dto);
		
		if(result !=null) {
			
			out.println("<script>");
			out.println("alert('로그인성공!!')");
			out.println("location.href='manager_detail.go'");
			out.println("</script>");
			
			
		}else {
			
			  out.println("<script>");
	            out.println("alert('아이디 또는 비밀번호가 틀립니다.');");
	            out.println("history.back();");
	            out.println("</script>");
			
			
		}
		
	}
	
	
	@GetMapping("manager_detail.go")
	public String managerDetail(Model model){
		
			List<ParkingDTO> parkingList = mapper.pList(); // 현재 주차 현황
			List<ParkingRecordDTO> parkingRecords = mapper.parkingRecords(); // 주차 기록

			
			model.addAttribute("parkingList", parkingList);
			model.addAttribute("parkingRecords", parkingRecords);
		
		return "manager_detail";
		
	}
	
	
	
}
