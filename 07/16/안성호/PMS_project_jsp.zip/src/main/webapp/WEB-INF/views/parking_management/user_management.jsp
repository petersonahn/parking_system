<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
		
		$(".userRegForm").submit(function(e) {
			
			if($("#user_car_num").val().trim() === "") {
				alert("차량 번호를 입력하세요.");
				$("#user_car_num").focus();
				e.preventDefault();
			}
			
			else if($("#user_id").val().trim() === "") {
				alert("회원 아이디를 입력하세요.");
				$("#user_id").focus();
				e.preventDefault();
			}
			
			else if($("#user_name").val().trim() === "") {
				alert("회원 이름을 입력하세요.");
				$("#user_name").focus();
				e.preventDefault();
			}
			
			else if($("#user_phone").val().trim() === "") {
				alert("회원 연락처를 입력하세요.");
				$("#user_phone").focus();
				e.preventDefault();
			}
			
		});
		
		$(".user_button").click(function() {
			const user_id = $(this).data("userId");
	        const user_car_num = $(this).data("userCarNum");
	        const user_name = $(this).data("userName");
	        const user_phone = $(this).data("userPhone");
			
	        let user_html = "<div>";
	        user_html += "<h2>회원 정보 관리</h2>";
	        user_html += "</div>";
	        
			user_html += "<div><table border='1'>";
			
			user_html += "<tr>";
			user_html += "<th>회원 아이디</th>";
			user_html += "<td>";
			user_html += user_id;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "<tr>";
			user_html += "<th>차량 번호</th>";
			user_html += "<td>";
			user_html += user_car_num;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "<tr>";
			user_html += "<th>회원 이름</th>";
			user_html += "<td>";
			user_html += user_name;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "<tr>";
			user_html += "<th>회원 연락처</th>";
			user_html += "<td>";
			user_html += user_phone;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "</table></div>";
			
			user_html += "<div class='button'>";
			user_html += "<button onclick='modify(\"" + user_id + "\", \"" + user_car_num + "\", \"" + user_name + "\", \"" + user_phone + "\")'>수정</button>";
			user_html += "<button onclick=\"if(confirm('회원 정보를 정말 삭제하시겠습니까?')) location.href='user_delete.go?user_car_num=" + user_car_num + "'\">삭제</button>";
			user_html += "</div>";
			user_html += "<span class='close_btn' onclick='closeModal()'>&times;</span>";
			
			document.getElementById("user_content").innerHTML = user_html;
			document.getElementById("modal").style.display = "block";
		});
		
	});
	
	
	function modify(user_id, user_car_num, user_name, user_phone) {
		
		$(document).ready(function() {
			
			$(".userModForm").submit(function(e) {
				
				if($("#mod_user_name").val().trim() === "") {
					alert("회원 이름을 입력하세요.");
					$("#mod_user_name").focus();
					e.preventDefault();
				}
				
				else if($("#mod_user_phone").val().trim() === "") {
					alert("회원 연락처를 입력하세요.");
					$("#mod_user_phone").focus();
					e.preventDefault();
				}
				
			});
			
		});
		
		let mod_html = "<div>";
        mod_html += "<h2>회원 정보 수정</h2>";
        mod_html += "</div>";
        
        mod_html += "<form class='userModForm' method='post' action='user_modify.go'>";
		mod_html += "<div><table border='1'>";
		
		mod_html += "<tr>";
		mod_html += "<th>회원 아이디</th>";
		mod_html += "<td><input name='user_id' value="+user_id+" readOnly>";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "<tr>";
		mod_html += "<th>차량 번호</th>";
		mod_html += "<td><input name='user_car_num' value="+user_car_num+" readOnly>";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "<tr>";
		mod_html += "<th>회원 이름</th>";
		mod_html += "<td><input id='mod_user_name' name='user_name' value="+user_name+">";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "<tr>";
		mod_html += "<th>회원 연락처</th>";
		mod_html += "<td><input id='mod_user_phone' name='user_phone' value="+user_phone+">";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "</table></div>";
		
		mod_html += "<div class='button'>";
		mod_html += "<button type='submit'>수정</button>";
		mod_html += "</form>";
		mod_html += "</div>";
		mod_html += "<span class='close_btn' onclick='closeModModal()'>&times;</span>";
		
		document.getElementById("user_modify").innerHTML = mod_html;
		
		closeModal();
		
		document.getElementById("modModal").style.display = "block";
		
	}
	
	
	function showUserRegModal() {
		document.getElementById("userRegModal").style.display = "block";
	}
	
	function closeUserRegModal() {
	
		document.getElementById("user_car_num").value = "";
		document.getElementById("user_id").value = "";
		document.getElementById("user_name").value = "";
		document.getElementById("user_phone").value = "";
		
		document.getElementById("userRegModal").style.display = "none";
	}
	
	function closeModal() {
		document.getElementById("modal").style.display = "none";
	}
	
	function closeModModal() {
		document.getElementById("modModal").style.display = "none";
	}

	
</script>

<style>
    * {
        box-sizing: border-box;
        font-family: 'Segoe UI', '맑은 고딕', sans-serif;
        margin: 0;
        padding: 0;
    }

    body {
        background-color:#eaf3fb;
    }

    .main {
        width: 1200px;
        margin: 100px auto;
        background-color: white;
        border-radius: 20px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        padding: 60px 80px;
    }

    .header {
        text-align: center;
        margin-bottom: 50px;
    }

    .header h2 {
        font-size: 42px;
        color: #a0a0a0;
        font-weight: 700;
    }
    
    h4 {
		color: #555;
		font-weight: 500;
		margin-bottom: 10px;
		margin-right: 5px;
		text-align: right;
	}

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 40px;
    }

    th, td {
        padding: 15px;
        text-align: center;
        border: 1px solid #ddd;
    }

    th {
        background-color: #3498db;
        color: white;
    }

    .user_button:hover {
        background-color: #f1f1f1;
        cursor: pointer;
    }

    .button {
        text-align: center;
        margin-top: 20px;
    }

    .button button {
        padding: 14px 28px;
        margin: 0 10px;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        font-weight: bold;
        background-color: #3498db;
        color: white;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .button button:hover {
        background-color: #2874bd;
        transform: translateY(-3px);
    }

    #modal, #modModal, #userRegModal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
    }

    #user_content, #user_modify, #user_reg {
        background-color: white;
        margin: 8% auto;
        padding: 30px;
        border-radius: 16px;
        width: 500px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        position: relative;
    }

    #user_content h2, #user_modify h2, #user_reg h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #a0a0a0;
    }

    #user_content table, #user_modify table, #user_reg table {
        width: 100%;
        border-collapse: collapse;
    }

    #user_content th, #user_modify th, #user_reg th {
        width: 30%;
        background-color: #3498db;
        padding: 10px;
        text-align: left;
    }

    #user_content td, #user_modify td, #user_reg td {
        padding: 10px;
    }

    input {
        width: 100%;
        padding: 8px 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 6px;
    }

    .close_btn {
        position: absolute;
        top: 15px;
        right: 20px;
        font-size: 24px;
        cursor: pointer;
        color: #888;
    }

    .close_btn:hover {
        color: #000;
    }
    
    .btn {
		position: fixed;
		bottom: 40px;
		right: 40px;
		z-index: 1000;
	}
	
	.btn button.home-btn {
		background-color: #3498db;
		border: none;
		border-radius: 50%;
		width: 70px;
		height: 70px;
		cursor: pointer;
		transition: background-color 0.3s ease, transform 0.2s ease;
		display: flex;
		align-items: center;
		justify-content: center;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
	}
	
	.btn button.home-btn:hover {
		background-color: #2874bd;
		transform: scale(1.1);
	}
	
	.pagination {
		text-align: center;
		margin-top: 20px;
	}

	.pagination a {
		margin: 0 5px;
		text-decoration: none;
		color: #3498db;
		font-weight: 500;
		transition: color 0.2s ease;
	}

	.pagination a:hover {
		color: #2874bd;
	}

	.pagination .active {
		font-weight: bold;
		color: #2d6ac0;
	}
	
	.searchUser {
	    display: flex;
	    align-items: center;
	    justify-content: center;
	    gap: 10px;
	    width: fit-content;
	    margin: 30px auto;
	    padding: 15px 20px;
	    background-color: white;
	    border-radius: 12px;
	    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
	}

	.searchUser select,
	.searchUser input[type="text"] {
		font-size: 16px;
		padding: 8px 12px;
		border: 1.5px solid #ccc;
		border-radius: 8px;
		margin: 0 5px;
		transition: border-color 0.3s ease, box-shadow 0.3s ease;
	}

	.searchUser select:focus, .searchUser input:focus {
		border-color: #3498db;
		outline: none;
		box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
	}

	.searchUser button {
		background-color: #3498db;
		color: white;
		border: none;
		padding: 10px 20px;
		border-radius: 8px;
		cursor: pointer;
		font-weight: 600;
		transition: background-color 0.3s ease, transform 0.2s ease;
		box-shadow: 0 4px 10px rgba(52, 152, 219, 0.3);
		width: 100px;
	}

	.searchUser button:hover {
		background-color: #2874bd;
		transform: translateY(-2px);
	}

	
</style>

<title>회원 관리</title>
</head>
<body>

	<div class="main">
		<div class="header">
			<h2>회원 관리</h2>
		</div>
		
		<form class="searchUser" method="post" action="<%=request.getContextPath() %>/user_search_management.go">
			<select name="field">
				<option value="user_car_num">차량 번호</option>
				<option value="user_name">회원 이름</option>
			</select>
			<input class="search-input" name="keyword" type="text">
			<button type="submit">검색</button>
		</form>
		
		<h4>등록된 회원 수 : ${paging.totalRecord } 명</h4>
	
		<c:set var="uList" value="${userList }" />
		
		<div class="list">
			<table border="1">
				<tr>
					<th>회원 아이디</th>
					<th>차량 번호</th>
					<th>회원 이름</th>
					<th>회원 연락처</th>
				</tr>
				
				<c:forEach var="user" items="${uList }">
					<tr class="user_button" 
						data-user-id="${user.user_id}" 
					    data-user-car-num="${user.user_car_num}"
					    data-user-name="${user.user_name}" 
					    data-user-phone="${user.user_phone}">
					    
						<td>${user.user_id }</td>
						<td>${user.user_car_num }</td>
						<td>${user.user_name }</td>
						<td>${user.user_phone }</td>
					</tr>
				</c:forEach>
			</table>
			<br>
			<div align="center">
			  	<!-- 페이징 버튼 영역 -->
			  	<div class="pagination">
				  	<c:if test="${paging.page > paging.block }">
				  		<a href="user_management.go?page=1">[맨 처음]</a>
					    <a href="user_management.go?page=${paging.startBlock - 1 }">◀</a>
					</c:if>
					  
					<c:forEach begin="${paging.startBlock}" end="${paging.endBlock}" var="i">
				  		<c:if test="${i == paging.page}">
				    		<b><a href="user_management.go?page=${i}">[${i}]</a></b>
				  		</c:if>
				  		
				 		<c:if test="${i != paging.page}">
				    		<a href="user_management.go?page=${i}">[${i}]</a>
				  		</c:if>
					</c:forEach>
				
					<c:if test="${paging.endBlock < paging.allPage}">
				  		<a href="user_management.go?page=${paging.endBlock + 1}">▶</a>
				  		<a href="user_management.go?page=${paging.allPage}">[맨 마지막]</a>
					</c:if>
				</div>
			</div>
		</div>
		<br>
		
		<div class="button">
			<button onclick="showUserRegModal()">회원 등록</button>
		</div>
		
		<div class="btn">
		  <button class="home-btn" onclick="location.href='manager_main.go'"> 
		    <span style="font-size: 28px; color: white;">↩</span>
		  </button>
		</div>
		
	</div>
	
	<div id="userRegModal" style="display : none;">
		<div id="user_reg">
			<div>
				<h2>회원 등록</h2>
			</div>
		
			<form class="userRegForm" method="post" action="<%=request.getContextPath() %>/user_registration_ok.go">
				<div>
				
					<table border="1">
						<tr>
							<th>차량 번호</th>
							<td><input id="user_car_num" name="user_car_num"></td>
						</tr>
					
						<tr>
							<th>회원 아이디</th>
							<td><input id="user_id" name="user_id"></td>
						</tr>
						
						<tr>
							<th>회원 이름</th>
							<td><input id="user_name" name="user_name"></td>
						</tr>
						
						<tr>
							<th>회원 연락처</th>
							<td><input id="user_phone" name="user_phone"></td>
						</tr>
					</table>
				</div>
				
				<div class="button">
					<button type="submit">등록</button>
					<button type="reset" onclick="location.href='user_management.go'">취소</button>
				</div>
			</form>
			<span class='close_btn' onclick='closeUserRegModal()'>&times;</span>
		</div>
	</div>
	
	<div id="modal" style="display : none;">
		<div id="user_content"></div>
	</div>
	
	<div id="modModal" style="display : none;">
		<div id="user_modify"></div>
	</div>

</body>
</html>