package com.boot.parking.model;

import java.util.List;
import java.util.Map;
import java.util.Date;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ParkingMapper {
	
	ManagerDTO login(ManagerDTO dto); // 관리자 로그인

	List<ParkingDTO> pList();
	
	List<UsersDTO> userList(Page pdto);
	
	List<UsersDTO> userSearchList(Page pdto);
	
	int ucount();	// 전체 회원 수
	
	int userSearchCount(Map<String, String> map);	// 검색된 회원 수
	
	
	
	int A_section_count();	// A구역 주차 가능 공간 갯수
	
	int B_section_count();	// B구역 주차 가능 공간 갯수
	
	
	
	CarsDTO car(String car_num);	// car_num -> 해당 CarsDTO
	
	String search_car(String car_num);	// car_num -> 해당 ParkingDTO의 parking_id (차량 위치 조회)
	
	
	
	int in_car(String car_num);		// car_num -> 차량 입차
	
	int parking(ParkingDTO pdto);	// 차량 입차 시 주차 구역 선택 후 parking 테이블에 저장
	
	int out_time_update(String car_num);	// 출차 시 car 테이블에 car_num에 해당하는 차량의 out_time 저장
	
	int out(String car_num);  // 출차 처리 시 car 테이블에서 car_num에 해당하는 차량의 데이터 삭제
	
	CarsDTO car_info(String car_num);	// car_num -> 해당 CarsDTO
	
	UsersDTO user_info(String car_num);		// car_num -> 해당 UsersDTO
	
	int record_in(ParkingRecordDTO rdto);	// 차량 입차 시 parking_record 테이블에 입차 기록 저장.
	
	int record_out(ParkingRecordDTO rdto);	// 차량 출차 시 parking_record 테이블에 출차 기록 저장.
	
	// 입차 시간 조회
	Date selectInTimeByCarNum(String car_num);

	// 출차 시 주차기록의 PK를 조회하는 메서드
	int selectRecordNumByCarNumAndInTime(@Param("car_num") String car_num, @Param("in_time") Date in_time);
	
	// 주차 기록
	List<ParkingRecordDTO> car_list(Page pdto);

	List<ParkingRecordDTO> parkingRecords();
	
	int count();
	
	int registration_user(UsersDTO udto);
	
	int scount(Map<String, String> map);

	List<ParkingRecordDTO> carlist_search(Page pdto);
	
	Integer searchamountfee(Map<String, String> map);
	
	// 요금 정보 조회
	ParkingFeeDTO getFee();

	// 요금 정보 수정
	int updateFee(ParkingFeeDTO fee);
	
	int userModify(UsersDTO udto);
	
	int userDelete(String user_car_num);
	
	int amountfee();
}
