package com.boot.parking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.parking.model.CarsDTO;
import com.boot.parking.model.ParkingDTO;
import com.boot.parking.model.ParkingFeeDTO;
import com.boot.parking.model.ParkingMapper;
import com.boot.parking.model.ParkingRecordDTO;
import com.boot.parking.model.UsersDTO;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ParkingController {

	@Autowired
	private ParkingMapper mapper;
	
	@GetMapping("/")
	public String main() {
		return "main";
	}
	
	
	// 입차 -----------------------------------------------------------
	
	@GetMapping("parking_in.go")
	public String in() {
		return "parking_in";
	}
	
	@RequestMapping("choose_parking_spot.go")
	public String parking(@RequestParam("car_num") String car_num,
			Model model, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		CarsDTO car = this.mapper.car_info(car_num);
		
		if(car == null) {
			if(car_num == "") {
				out.println("<script>");
				out.println("alert('차량번호를 입력하세요.')");
				out.println("history.back()");
				out.println("</script>");
				
				return null;
			}
			
			List<ParkingDTO> plist = this.mapper.pList();
			int A_count = this.mapper.A_section_count();
			int B_count = this.mapper.B_section_count();
			
			model.addAttribute("plist", plist)
				.addAttribute("car_num", car_num)
				.addAttribute("A_count", A_count)
				.addAttribute("B_count", B_count);
			
			return "choose_parking_spot";
			
		}else {
			out.println("<script>");
			out.println("alert('이미 주차 되어있는 차량입니다.')");
			out.println("history.back()");
			out.println("</script>");
			
			return null;
		}
		
	}
	
	@GetMapping("choose_parking_spot_ok.go")
	public void parking_ok(ParkingDTO pdto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		ParkingRecordDTO rdto = new ParkingRecordDTO();
		
		int check = this.mapper.in_car(pdto.getCar_num());
		
		if(check > 0) {
			int chk = this.mapper.parking(pdto);
			
			if(chk > 0) {
				UsersDTO user = this.mapper.user_info(pdto.getCar_num());
				CarsDTO car = this.mapper.car_info(pdto.getCar_num());
				
				if(user == null) {
					rdto.setUser_id("");
				}else {
					rdto.setUser_id(user.getUser_id());
				}
				
				rdto.setCar_num(car.getCar_num());
				rdto.setIn_time(car.getIn_time());
				rdto.setOut_time(null); // 출차 시간은 아직 없으므로 null
	            rdto.setFee_amount(0);
	            rdto.setParking_id(pdto.getParking_id());
				
				this.mapper.record_in(rdto);
				
				out.println("<script>");
				out.println("alert('주차 완료')");
				out.println("location.href='/'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('오류 발생')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			out.println("<script>");
			out.println("alert('오류 발생(2)')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	// 입차. -----------------------------------------------------------

	
	
	// 출차 =======================================================
	
	@GetMapping("parking_out.go")
	public String went_out() {
		return "parking_out";
	}
	
	@PostMapping("parking_out_ok.go")
	public void went_out_ok(@RequestParam("car_num") String car_num,
	                        HttpServletResponse response) throws IOException {

		response.setContentType("text/html; charset=UTF-8");
	    PrintWriter out = response.getWriter();

	    Date inTime = mapper.selectInTimeByCarNum(car_num);

	    if (inTime == null) {
	        out.println("<script>");
	        out.println("alert('입차 기록이 존재하지 않습니다.');");
	        out.println("history.back();");
	        out.println("</script>");
	        return;
	    }

	    Date outTime = new Date();

	    long millis = outTime.getTime() - inTime.getTime();
	    long minutes = millis / (1000 * 60);
	    
	    ParkingFeeDTO feePolicy = mapper.getFee();

	    int fee = 0;
	    int fee_0 = 0;
	    int fee_1 = 0;
	    boolean user_check = false;
	    
	    UsersDTO user_info = this.mapper.user_info(car_num);
	    
	    if(user_info == null) {
	    	// 출차하고자 하는 차량이 회원으로 등록된 차량이 아닌 경우.
	    	
	    	if (minutes > 1440) {
		        fee_0 = (int)(Math.floor((double)(minutes / 1440))) * feePolicy.getMax_fee_per_day();
		        fee_1 = (int) (Math.floor((double) 
	    				((minutes % 1440) / feePolicy.getUnit_minutes()))) * feePolicy.getHourly_fee();
	    		if(fee_1 > feePolicy.getMax_fee_per_day()) {
	    			fee = fee_0 + feePolicy.getMax_fee_per_day();
	    		}else {
	    			fee = fee_0 + fee_1;
	    		}
		    }else {
		    	if (minutes > feePolicy.getBase_minutes()) {
		    		fee_0 = (int) (Math.floor((double) 
		    				(minutes / feePolicy.getUnit_minutes()))) * feePolicy.getHourly_fee();
		    		if(fee_0 > feePolicy.getMax_fee_per_day()) {
		    			fee = feePolicy.getMax_fee_per_day();
		    		}else {
		    			fee = fee_0;
		    		}
		    	}else {
		    		fee = feePolicy.getBase_fee();
		    	}
		    }
	    	
	    }else {
	    	// 출차하고자 하는 차량이 회원으로 등록된 차량인 경우.
	    	user_check = true;
	    }

	    // parking_record 조회해서 PK 가져오기 (별도 메서드 필요)
	    int parkingRecNum = mapper.selectRecordNumByCarNumAndInTime(car_num, inTime);
	    if (parkingRecNum == 0) {
	        out.println("<script>");
	        out.println("alert('주차 기록이 없습니다.');");
	        out.println("history.back();");
	        out.println("</script>");
	        return;
	    }

	    ParkingRecordDTO record = new ParkingRecordDTO();
	    record.setParking_rec_num(parkingRecNum);
	    record.setCar_num(car_num);
	    record.setIn_time(inTime);
	    record.setOut_time(outTime);
	    record.setFee_amount(fee);

	    int updateCount = mapper.record_out(record);

	    if (updateCount > 0) {
	        int delParking = mapper.out(car_num);           // parking 테이블 car_num null 처리

	        if (delParking > 0) {
	        	if(user_check == false) {
	        		// 회원이 아닌 경우.
	        		out.println("<script>");
		            out.println("alert('출차 완료. 정산 금액 : " + fee + " 원');");
		            out.println("location.href='/'");
		            out.println("</script>");
	        	}else {
	        		// 회원인 경우.
	        		out.println("<script>");
		            out.println("alert('정기 결제 차량입니다. 정산 금액 : " + fee + " 원');");
		            out.println("location.href='/'");
		            out.println("</script>");
	        	}
	            
	        } else {
	            out.println("<script>");
	            out.println("alert('출차 처리 오류');");
	            out.println("history.back();");
	            out.println("</script>");
	        }
	    } else {
	        out.println("<script>");
	        out.println("alert('주차 기록 업데이트 실패');");
	        out.println("history.back();");
	        out.println("</script>");
	    }
	}
	
	// 출차. =======================================================
	
	
	
	// 차량 조회 --------------------------------------------------------

	@GetMapping("search_car.go")
	public String search_car() {
		return "search_car";
	}
	
	
	@PostMapping("search_car_location.go")
	public String search_car_ok(@RequestParam("car_num") String car_num,
			HttpServletResponse response, Model model) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String parking_id = this.mapper.search_car(car_num);
		List<ParkingDTO> plist = this.mapper.pList();
		
		model.addAttribute("parking_id", parking_id)
			.addAttribute("car_num", car_num)
			.addAttribute("plist", plist);
		
		String res = null;
		
		if(parking_id != null) {
			res = "search_car_location";
		}else {
			out.println("<script>");
			out.println("alert('조회된 차량번호가 존재하지 않습니다.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return res;
		
	}
	
	// 차량 조회. --------------------------------------------------------
	
	
}
