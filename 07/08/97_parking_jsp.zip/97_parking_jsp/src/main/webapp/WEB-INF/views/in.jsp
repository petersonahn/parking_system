<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style type="text/css">
	.main{
		width : 800px;
		display : flex;
		flex-direction : column;
		margin : 100px auto 100px;
		border : 2px solid black;
		border-radius : 10px;
		padding-bottom : 50px;
	}

	.header{
		margin : 50px auto;
	}
	
	.body {
		display : flex;
	}
	
	.body form {
		display : flex;
		margin : auto;
		gap : 40px;
	}
	
	.body input {
		font-size: 20px;
		text-align: center;
	}
	
	.body button {
		padding : 20px 30px 20px;
		border : 0px;
		border-radius : 5px;
		background-color : lightgray;
		cursor : pointer;
	}
	
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">

	$(document).ready(function() {
		$(".car_num_input").click(function() {
			
			const koreanChars = [
                "가", "나", "다", "라", "마", "거", "너", "더", "러", "머",
                "버", "서", "어", "저", "고", "노", "도", "로", "모", "보",
                "소", "오", "조", "구", "누", "두", "루", "무", "부", "수",
                "우", "주", "아", "바", "사", "자", "배", "허", "하", "호"
            ];

            const firstNumber = Math.floor(Math.random() * 90) + 10;   // 10 ~ 99
            const koreanChar = koreanChars[Math.floor(Math.random() * koreanChars.length)];
            const lastNumber = Math.floor(Math.random() * 9000) + 1000; // 1000 ~ 9999

            const carNum = firstNumber + koreanChar + lastNumber;
		    
	        $(".car_num_input").val(carNum);
		});
	});

</script>

<title>Insert title here</title>
</head>
<body>
	
	<div class="main">
	
		<div class="header">
			<h1>차량 번호 입력</h1>
		</div>
		
		<div class="body">
			<form method="post" action="parking.go">
			
				<input class="car_num_input" name="car_num" value="">
				
				<button type="submit">입력</button>
				
			</form>	
		</div>
		
	</div>

</body>
</html>