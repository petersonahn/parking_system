<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
  <title>차량 리스트</title>
  <style>
    .pagination a {
      margin: 0 5px;
      text-decoration: none;
      color: black;
    }
    .pagination .active {
      font-weight: bold;
      color: black;
    }
  </style>
</head>
<body>
<div>
  <h2>입차 차량 리스트</h2>

  <table border="1">
    <tr>
      <th>차량번호</th>
      <th>입차시간</th>
      <th>출차시간</th>
    </tr>

      <c:set var="list" value="${carList}" />
      <c:if test="${!empty list }">
	         	      
	    <c:forEach var="car" items="${list}">
	      <tr>
	        <td>${car.car_num}</td>
	        <td><fmt:formatDate value="${car.in_time}" pattern="yyyy-MM-dd HH:mm:ss"/></td>
	        <td>
	          <c:choose>
	            <c:when test="${empty car.out_time}">
	              <span style="color:red;">주차중</span>
	            </c:when>
	            <c:otherwise>
	              <fmt:formatDate value="${car.out_time}" pattern="yyyy-MM-dd HH:mm:ss"/>
	            </c:otherwise>
	          </c:choose>
	        </td>
	      </tr>
	    </c:forEach>
      </c:if>
    
    
	      <c:if test="${empty list }">
	         <tr>
	            <td colspan="4" align="center">
	               <h3>전체 게시물 리스트가 없습니다.....</h3>
	            </td>
	         </tr>
	      </c:if>
	      
	      
  </table>

  <br>

</div>  

</body>
</html>
