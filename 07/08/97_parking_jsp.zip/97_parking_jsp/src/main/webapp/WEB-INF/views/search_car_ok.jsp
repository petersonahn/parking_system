<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style type="text/css">
	.list{
		display : flex;
	}
	
	.list td{
		width : 40px;
		text-align : center;
	}
	
	.on{
		background-color: skyblue;
	}
	
	.off{
		background-color: gray;
	}
	
</style>
<title>Insert title here</title>
</head>
<body>

	<c:set var="car_location" value="${parking_id }" />

	<div>
		<h2>조회된 차량의 위치는 '${car_location }' 입니다.</h2>
	</div>

	<div class="list">
		
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
				
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index < 10}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 9 and status.index < 20}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 19 and status.index < 30}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 29 and status.index < 40}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
		&nbsp;&nbsp;&nbsp;
		<div>
			<table border="1">
				<c:set var="List" value="${plist }" />
			    <c:forEach var="list" items="${List }" varStatus="status">
			    	<c:if test="${status.index > 39 and status.index < 50}">
			    		<tr>
					    	<td>${list.getParking_id() }</td>
					    	
					    	<c:if test="${list.getParking_id() != car_location}">
						    	<td class="off">
						    		<input type="hidden" class="val" value="${list.getParking_id() }"/>
						    		&nbsp;
						    	</td>
						    </c:if>
						    
						    <c:if test="${list.getParking_id() == car_location}">
						    	<td class="on">&nbsp;</td>
						    </c:if>
						</tr>
				    </c:if>
			    </c:forEach> 
			</table>
		</div>
		
	</div>
	<br>
	
	<div class="btn">
		<button onclick="location.href='/'">메인</button>
	</div>

</body>
</html>