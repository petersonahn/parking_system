<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style type="text/css">
	.main{
		width : 800px;
		display : flex;
		flex-direction : column;
		margin : 100px auto 100px;
		border : 2px solid black;
		border-radius : 10px;
		padding-bottom : 50px;
	}

	.header{
		margin : 50px auto;
	}
	
	.main > form {
		display : flex;
	}
	
	.body {
		display : flex;
		margin : auto;
		gap : 40px;
	}
	
	.body > input {
		font-size: 20px;
	}
	
	.body button{
		padding : 20px 30px 20px;
		border : 0px;
		border-radius : 5px;
		background-color : lightgray;
		cursor : pointer;
	}
	
</style>
<title>Insert title here</title>
</head>
<body>

	<div class="main">
		
		<div class="header">
			<h1>주차 관제 시스템</h1>
		</div>
		
		<form method="post" action="<%=request.getContextPath() %>/search_car_ok.go">
			<div class="body">
				<h3>조회할 차량 번호 입력</h3>
				<input name="car_num" />
				<button type="submit">조회</button>
			</div>
		</form>
		
	</div>
	
</body>
</html>