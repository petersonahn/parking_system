package com.boot.parking.model;

import lombok.Data;

@Data
public class ParkingRecordDTO {

	private int parking_rec_num;
	private String car_num;
	private java.util.Date in_time;
	private java.util.Date out_time;
	private String user_id;
	
}
