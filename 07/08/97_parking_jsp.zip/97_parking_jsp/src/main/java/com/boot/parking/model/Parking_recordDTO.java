package com.boot.parking.model;

import java.util.Date;

import lombok.Data;

@Data
public class Parking_recordDTO {

	
	private int parking_rec_num;      
	private String car_num;
	private Date in_time;
	private Date out_time;
	private String user_id;
}
