package com.boot.parking.model;

import lombok.Data;

@Data
public class CarsDTO {

	private String car_num;
	private String in_time;
	private String out_time;
	
}
