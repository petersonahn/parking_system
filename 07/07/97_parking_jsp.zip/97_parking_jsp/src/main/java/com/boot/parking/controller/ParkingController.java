package com.boot.parking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.parking.model.ParkingDTO;
import com.boot.parking.model.ParkingMapper;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ParkingController {

	@Autowired
	private ParkingMapper mapper;
	
	@GetMapping("/")
	public String main() {
		return "main";
	}
	
	@GetMapping("came_in.go")
	public String in() {
		return "in";
	}
	
	@RequestMapping("parking.go")
	public String parking(@RequestParam("car_num") String car_num,
			Model model) {
		List<ParkingDTO> plist = this.mapper.pList();
		model.addAttribute("plist", plist)
			.addAttribute("car_num", car_num);
		
		return "parking";
	}
	
	@GetMapping("parking_ok.go")
	public void parking_ok(ParkingDTO pdto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		int check = this.mapper.in_car(pdto.getCar_num());
		
		if(check > 0) {
			int chk = this.mapper.parking(pdto);
			
			if(chk > 0) {
				out.println("<script>");
				out.println("alert('주차 완료')");
				out.println("location.href='/'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('오류 발생')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			out.println("<script>");
			out.println("alert('오류 발생(2)')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@GetMapping("went_out.go")
	public String went_out() {
		return "out";
	}
	
	@PostMapping("went_out_ok.go")
	public void went_out_ok(@RequestParam("car_num") String car_num,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		int check = this.mapper.out_time_update(car_num);
		
		if(check > 0) {
			int chk = this.mapper.out(car_num);
			
			if(chk > 0) {
				out.println("<script>");
				out.println("alert('출차 처리 완료')");
				out.println("location.href='/'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('오류')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			out.println("<script>");
			out.println("alert('조회된 차량번호가 존재하지 않습니다.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@GetMapping("search_car.go")
	public String search_car() {
		return "search_car";
	}
	
	
	@PostMapping("search_car_ok.go")
	public String search_car_ok(@RequestParam("car_num") String car_num,
			HttpServletResponse response, Model model) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String parking_id = this.mapper.search_car(car_num);
		List<ParkingDTO> plist = this.mapper.pList();
		
		
		
		model.addAttribute("parking_id", parking_id)
			.addAttribute("plist", plist);
		
		String res = null;
		
		if(parking_id != null) {
			res = "search_car_ok";
		}else {
			out.println("<script>");
			out.println("alert('조회된 차량번호가 존재하지 않습니다.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return res;
		
	}
	
	
}
