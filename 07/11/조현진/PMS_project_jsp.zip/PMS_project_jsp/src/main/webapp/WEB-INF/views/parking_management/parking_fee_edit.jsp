<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
    body {
        background-color: #eaf3fb;
        font-family: 'Segoe UI', '맑은 고딕', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 100vh;
    }

    h1 {
        color: #2d6ac0;
        font-size: 28px;
        margin-top: 50px;
        font-weight: 700;
    }

    .form-container {
        background-color: #fff;
        padding: 30px 40px;
        border-radius: 12px;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
        width: 350px;
        box-sizing: border-box;
    }

    .form-container label {
        display: block;
        margin-bottom: 5px;
        font-weight: 600;
    }

    .input-group {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
        width: 100%;
    }

    .input-group input[type="number"] {
        flex: 1;
        padding: 8px 12px;
        border: 1.5px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
        box-sizing: border-box;
        min-width: 0;
    }

    .input-group span {
        margin-left: 8px;
        font-size: 15px;
        white-space: nowrap;
    }

    .input-group input[type="number"]:focus {
        border-color: #3498db;
        box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
        outline: none;
    }

    .button-group {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
        width: 100%;
    }

    .button-group button,
    .button-group input[type="submit"] {
        background-color: #3498db;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 600;
        transition: background-color 0.3s ease, transform 0.2s ease;
        box-shadow: 0 4px 10px rgba(52, 152, 219, 0.3);
        width: 48%;
        box-sizing: border-box;
    }

    .button-group button:hover,
    .button-group input[type="submit"]:hover {
        background-color: #2874bd;
        transform: translateY(-2px);
    }

</style>
<title>Insert title here</title>
</head>
<body>
	
	<h1>요금 정책 수정</h1>
    
    <div class="form-container">
        <form action="fee_update.go" method="post">
            
            <label>기본요금:</label>
            <div class="input-group">
                <input type="number" name="base_fee" value="${fee.base_fee != null ? fee.base_fee : 0}" required />
                <span>원</span>
            </div>

            <label>기본요금 적용 시간:</label>
            <div class="input-group">
                <input type="number" name="base_minutes" value="${fee.base_minutes != null ? fee.base_minutes : 0}" required />
                <span>분</span>
            </div>

            <label>시간당 요금:</label>
            <div class="input-group">
                <input type="number" name="hourly_fee" value="${fee.hourly_fee != null ? fee.hourly_fee : 0}" required />
                <span>원</span>
            </div>

            <label>요금 부과 단위:</label>
            <div class="input-group">
                <input type="number" name="unit_minutes" value="${fee.unit_minutes != null ? fee.unit_minutes : 0}" required />
                <span>분</span>
            </div>

            <label>1일 최대 요금:</label>
            <div class="input-group">
                <input type="number" name="max_fee_per_day" value="${fee.max_fee_per_day != null ? fee.max_fee_per_day : ''}" />
                <span>원</span>
            </div>

            <div class="button-group">
                <input type="submit" value="수정 완료" />
                <button type="button" onclick="location.href='manager_main.go'">취 소</button>
            </div>

        </form>
    </div>
	
</body>
</html>