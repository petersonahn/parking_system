<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
		
		$(".userRegForm").submit(function(e) {
			
			if($("#user_car_num").val().trim() === "") {
				alert("차량 번호를 입력하세요.");
				$("#user_car_num").focus();
				e.preventDefault();
			}
			
			else if($("#user_id").val().trim() === "") {
				alert("회원 아이디를 입력하세요.");
				$("#user_id").focus();
				e.preventDefault();
			}
			
			else if($("#user_name").val().trim() === "") {
				alert("회원 이름을 입력하세요.");
				$("#user_name").focus();
				e.preventDefault();
			}
			
			else if($("#user_phone").val().trim() === "") {
				alert("회원 연락처를 입력하세요.");
				$("#user_phone").focus();
				e.preventDefault();
			}
			
		});
		
		$(".user_button").click(function() {
			const user_id = $(this).data("userId");
	        const user_car_num = $(this).data("userCarNum");
	        const user_name = $(this).data("userName");
	        const user_phone = $(this).data("userPhone");
			
	        let user_html = "<div>";
	        user_html += "<h2>회원 정보 관리</h2>";
	        user_html += "</div>";
	        
			user_html += "<div><table border='1'>";
			
			user_html += "<tr>";
			user_html += "<th>회원 아이디</th>";
			user_html += "<td>";
			user_html += user_id;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "<tr>";
			user_html += "<th>차량 번호</th>";
			user_html += "<td>";
			user_html += user_car_num;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "<tr>";
			user_html += "<th>회원 이름</th>";
			user_html += "<td>";
			user_html += user_name;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "<tr>";
			user_html += "<th>회원 연락처</th>";
			user_html += "<td>";
			user_html += user_phone;
			user_html += "</td>";
			user_html += "</tr>";
			
			user_html += "</table></div>";
			
			user_html += "<div class='button'>";
			user_html += "<button onclick='modify(\"" + user_id + "\", \"" + user_car_num + "\", \"" + user_name + "\", \"" + user_phone + "\")'>수정</button>";
			user_html += "<button onclick=\"if(confirm('회원 정보를 정말 삭제하시겠습니까?')) location.href='user_delete.go?user_car_num=" + user_car_num + "'\">삭제</button>";
			user_html += "</div>";
			user_html += "<span class='close_btn' onclick='closeModal()'>&times;</span>";
			
			document.getElementById("user_content").innerHTML = user_html;
			document.getElementById("modal").style.display = "block";
		});
		
	});
	
	
	function modify(user_id, user_car_num, user_name, user_phone) {
		
		$(document).ready(function() {
			
			$(".userModForm").submit(function(e) {
				
				if($("#mod_user_name").val().trim() === "") {
					alert("회원 이름을 입력하세요.");
					$("#mod_user_name").focus();
					e.preventDefault();
				}
				
				else if($("#mod_user_phone").val().trim() === "") {
					alert("회원 연락처를 입력하세요.");
					$("#mod_user_phone").focus();
					e.preventDefault();
				}
				
			});
			
		});
		
		let mod_html = "<div>";
        mod_html += "<h2>회원 정보 수정</h2>";
        mod_html += "</div>";
        
        mod_html += "<form class='userModForm' method='post' action='user_modify.go'>";
		mod_html += "<div><table border='1'>";
		
		mod_html += "<tr>";
		mod_html += "<th>회원 아이디</th>";
		mod_html += "<td><input name='user_id' value="+user_id+" readOnly>";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "<tr>";
		mod_html += "<th>차량 번호</th>";
		mod_html += "<td><input name='user_car_num' value="+user_car_num+" readOnly>";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "<tr>";
		mod_html += "<th>회원 이름</th>";
		mod_html += "<td><input id='mod_user_name' name='user_name' value="+user_name+">";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "<tr>";
		mod_html += "<th>회원 연락처</th>";
		mod_html += "<td><input id='mod_user_phone' name='user_phone' value="+user_phone+">";
		mod_html += "</input></td>";
		mod_html += "</tr>";
		
		mod_html += "</table></div>";
		
		mod_html += "<div>";
		mod_html += "<button type='submit'>수정</button>";
		mod_html += "</form>";
		mod_html += "</div>";
		mod_html += "<span class='close_btn' onclick='closeModModal()'>&times;</span>";
		
		document.getElementById("user_modify").innerHTML = mod_html;
		
		closeModal();
		
		document.getElementById("modModal").style.display = "block";
		
	}
	
	
	
	function showUserRegModal() {
		document.getElementById("userRegModal").style.display = "block";
	}
	
	function closeUserRegModal() {
		document.getElementById("userRegModal").style.display = "none";
	}
	
	function closeModal() {
		document.getElementById("modal").style.display = "none";
	}
	
	function closeModModal() {
		document.getElementById("modModal").style.display = "none";
	}

	
</script>

<style>
	#modal, #modModal, #userRegModal {
		display: none;
		position: fixed;
		z-index: 1000;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
	}

	#user_content, #user_modify, #user_reg {
		background-color: white;
		margin: 10% auto;
		padding: 20px;
		border: 1px solid #888;
		width: 400px;
		box-shadow: 0 0 10px #000;
		border-radius: 8px;
		position: relative;
	}

	.close_btn {
		position: absolute;
		top: 10px;
		right: 15px;
		font-size: 18px;
		cursor: pointer;
		color: #888;
	}
	.close_btn:hover {
		color: #000;
	}
</style>

<title>Insert title here</title>
</head>
<body>

	<div>
		<div>
			<h2>회원 관리</h2>
		</div>
	
		<c:set var="uList" value="${userList }" />
		
		<div class="list">
			<table border="1">
				<tr>
					<th>회원 아이디</th>
					<th>차량 번호</th>
					<th>회원 이름</th>
					<th>회원 연락처</th>
				</tr>
				
				<c:forEach var="user" items="${uList }">
					<tr class="user_button" 
						data-user-id="${user.user_id}" 
					    data-user-car-num="${user.user_car_num}"
					    data-user-name="${user.user_name}" 
					    data-user-phone="${user.user_phone}">
					    
						<td>${user.user_id }</td>
						<td>${user.user_car_num }</td>
						<td>${user.user_name }</td>
						<td>${user.user_phone }</td>
					</tr>
				</c:forEach>
			</table>
		</div>
		<br>
		
		<div class="button">
			<button onclick="showUserRegModal()">회원 등록</button>
			<button onclick="location.href='manager_main.go'">관리자 홈</button>
		</div>
	</div>
	
	<div id="userRegModal" style="display : none;">
		<div id="user_reg">
			<div>
				<h2>회원 등록</h2>
			</div>
		
			<form class="userRegForm" method="post" action="<%=request.getContextPath() %>/user_registration_ok.go">
				<div>
				
					<table border="1">
						<tr>
							<th>차량 번호</th>
							<td><input id="user_car_num" name="user_car_num"></td>
						</tr>
					
						<tr>
							<th>회원 아이디</th>
							<td><input id="user_id" name="user_id"></td>
						</tr>
						
						<tr>
							<th>회원 이름</th>
							<td><input id="user_name" name="user_name"></td>
						</tr>
						
						<tr>
							<th>회원 연락처</th>
							<td><input id="user_phone" name="user_phone"></td>
						</tr>
					</table>
				</div>
				
				<div class="button">
					<button type="submit">등록</button>
					<button type="reset" onclick="location.href='user_management.go'">취소</button>
				</div>
			</form>
			<span class='close_btn' onclick='closeUserRegModal()'>&times;</span>
		</div>
	</div>
	
	<div id="modal" style="display : none;">
		<div id="user_content"></div>
	</div>
	
	<div id="modModal" style="display : none;">
		<div id="user_modify"></div>
	</div>

</body>
</html>