package com.boot.parking.model;

import lombok.Data;

@Data
public class ParkingDTO {

	private String parking_id;
	private String car_num;
	
}
