package com.boot.parking.model;

import lombok.Data;

@Data
public class ManagerDTO {

	private String manager_id;
	private String manager_pwd;
	
}
