package com.boot.parking.model;

import lombok.Data;

@Data
public class ParkingFeeDTO {
    private int base_fee;
    private int base_minutes;
    private int hourly_fee;
    private int unit_minutes;
    private Integer max_fee_per_day; // null 허용 가능
}