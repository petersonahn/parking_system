<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style type="text/css">
	.main{
		width : 800px;
		display : flex;
		flex-direction : column;
		margin : 100px auto 100px;
		border : 2px solid black;
		border-radius : 10px;
		padding-bottom : 50px;
	}

	.header{
		margin : 50px auto;
	}
	
	.body {
		display : flex;
		margin : auto;
		gap : 40px;
	}
	
	.body button{
		padding : 20px 30px 20px;
		border : 0px;
		border-radius : 5px;
		background-color : lightgray;
		cursor : pointer;
	}
	
</style>
<title>Insert title here</title>
</head>
<body>

	<div class="main">
		<div class="header">
			<h1>주차 관제 시스템</h1>
		</div>
		
		<div class="body">
			<button onclick="location.href='came_in.go'">입 차</button>
			<button onclick="location.href='went_out.go'">출 차</button>
			<button onclick="location.href='search_car.go'">차 량<br>조 회</button>
		</div>
	</div>

</body>
</html>