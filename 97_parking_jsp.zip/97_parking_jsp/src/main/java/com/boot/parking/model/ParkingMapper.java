package com.boot.parking.model;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ParkingMapper {

	List<ParkingDTO> pList();
	
	String search_car(String car_num);
	
	int out_time_update(String car_num);
	
	int out(String car_num);
}
